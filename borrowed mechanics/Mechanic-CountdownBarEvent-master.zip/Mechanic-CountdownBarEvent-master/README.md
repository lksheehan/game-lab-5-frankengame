# Mechanic-CountdownBarEvent
 A countdown bar that fires an event. In this example, when the time's up the player jumps.
 
 See the mechanic here:
 https://playfulsystems.github.io/Mechanic-CountdownBarEvent/
